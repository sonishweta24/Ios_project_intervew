//import SwiftUI
//import CoreData
//
//struct PasswordModel: Identifiable {
//    var id: NSManagedObjectID
//    var accountType: String
//    var username: String
//    var password: String
//}
//
//class PasswordViewModel: ObservableObject {
//    private let viewContext = PersistenceController.shared.container.viewContext
//    
//    @Published var passwords: [PasswordModel] = []
//    
//    init() {
//        fetchPasswords()
//    }
//    
//    func fetchPasswords() {
//        let request: NSFetchRequest<Password> = Password.fetchRequest()
//        do {
//            let result = try viewContext.fetch(request)
//            self.passwords = result.map { PasswordModel(id: $0.objectID, accountType: $0.accountType ?? "", username: $0.username ?? "", password: $0.password ?? "") }
//        } catch {
//            print("Error fetching passwords: \(error)")
//        }
//    }
//    
//    func addPassword(accountType: String, username: String, password: String) {
//        let newPassword = Password(context: viewContext)
//        newPassword.accountType = accountType
//        newPassword.username = username
//        newPassword.password = password
//        
//        saveContext()
//        fetchPasswords()
//    }
//    
//    func updatePassword(id: NSManagedObjectID, accountType: String, username: String, password: String) {
//        do {
//            let passwordToUpdate = try viewContext.existingObject(with: id) as? Password
//            passwordToUpdate?.accountType = accountType
//            passwordToUpdate?.username = username
//            passwordToUpdate?.password = password
//            
//            saveContext()
//            fetchPasswords()
//        } catch {
//            print("Error updating password: \(error)")
//        }
//    }
//    
//    func deletePassword(id: NSManagedObjectID) {
//        do {
//            let passwordToDelete = try viewContext.existingObject(with: id)
//            viewContext.delete(passwordToDelete)
//            
//            saveContext()
//            fetchPasswords()
//        } catch {
//            print("Error deleting password: \(error)")
//        }
//    }
//    
//    private func saveContext() {
//        do {
//            try viewContext.save()
//        } catch {
//            print("Error saving context: \(error)")
//        }
//    }
//}

//
//import SwiftUI
//import CoreData

//class PasswordViewModel: ObservableObject {
//    private let viewContext = PersistenceController.shared.container.viewContext
//    
//    @Published var passwords: [PasswordModel] = []
//    
//    init() {
//        fetchPasswords()
//    }
//    
//    func fetchPasswords() {
//        let request: NSFetchRequest<Password> = Password.fetchRequest()
//        
//        do {
//            let result = try viewContext.fetch(request)
//            self.passwords = result.compactMap { password in
//                guard let accountType = password.accountType,
//                      let username = password.username,
//                      let passwordString = password.password,
//                      let decryptedUsername = EncryptionHelper.decrypt(username),
//                      let decryptedPassword = EncryptionHelper.decrypt(passwordString) else {
//                    return nil
//                }
//                return PasswordModel(
//                    id: password.objectID,
//                    accountType: accountType,
//                    username: decryptedUsername,
//                    password: decryptedPassword
//                )
//            }
//        } catch {
//            print("Failed to fetch passwords: \(error.localizedDescription)")
//        }
//    }
//
//    func addPassword(accountType: String, username: String, password: String) {
//        guard let encryptedUsername = EncryptionHelper.encrypt(username),
//              let encryptedPassword = EncryptionHelper.encrypt(password) else {
//            print("Failed to encrypt data")
//            return
//        }
//        
//        let newPassword = Password(context: viewContext)
//        newPassword.accountType = accountType
//        newPassword.username = encryptedUsername
//        newPassword.password = encryptedPassword
//        
//        do {
//            try viewContext.save()
//            fetchPasswords()
//        } catch {
//            print("Failed to save password: \(error.localizedDescription)")
//        }
//    }
//
//    func updatePassword(id: NSManagedObjectID, accountType: String, username: String, password: String) {
//        guard let encryptedUsername = EncryptionHelper.encrypt(username),
//              let encryptedPassword = EncryptionHelper.encrypt(password) else {
//            print("Failed to encrypt data")
//            return
//        }
//        
//        do {
//            if let passwordToUpdate = try viewContext.existingObject(with: id) as? Password {
//                passwordToUpdate.accountType = accountType
//                passwordToUpdate.username = encryptedUsername
//                passwordToUpdate.password = encryptedPassword
//                
//                try viewContext.save()
//                fetchPasswords()
//            }
//        } catch {
//            print("Failed to update password: \(error.localizedDescription)")
//        }
//    }
//
//    func deletePassword(id: NSManagedObjectID) {
//        do {
//            if let passwordToDelete = try viewContext.existingObject(with: id) as? Password {
//                viewContext.delete(passwordToDelete)
//                try viewContext.save()
//                fetchPasswords()
//            }
//        } catch {
//            print("Failed to delete password: \(error.localizedDescription)")
//        }
//    }
//}


import SwiftUI
import CoreData
 
struct PasswordModel: Identifiable {
    var id: NSManagedObjectID
    var accountType: String
    var username: String
    var password: String
}
 
class PasswordViewModel: ObservableObject {
    private let viewContext = PersistenceController.shared.container.viewContext
    @Published var passwords: [PasswordModel] = []
 
    init() {
        fetchPasswords()
    }
 
    func fetchPasswords() {
        let request: NSFetchRequest<Password> = Password.fetchRequest()
        do {
            let result = try viewContext.fetch(request)
            self.passwords = result.compactMap { password in
                guard let accountType = password.accountType,
                      let username = password.username,
                      let passwordString = password.password,
                      let decryptedUsername = EncryptionHelper.decrypt(username),
                      let decryptedPassword = EncryptionHelper.decrypt(passwordString) else {
                    print("Invalid data encountered while fetching passwords.")
                    return nil
                }
                return PasswordModel(
                    id: password.objectID,
                    accountType: accountType,
                    username: decryptedUsername,
                    password: decryptedPassword
                )
            }
        } catch {
            print("Failed to fetch passwords: \(error.localizedDescription)")
        }
    }
 
    func addPassword(accountType: String, username: String, password: String) {
        guard let encryptedUsername = EncryptionHelper.encrypt(username),
              let encryptedPassword = EncryptionHelper.encrypt(password) else {
            print("Failed to encrypt data")
            return
        }
        let newPassword = Password(context: viewContext)
        newPassword.accountType = accountType
        newPassword.username = encryptedUsername
        newPassword.password = encryptedPassword
        do {
            try viewContext.save()
            fetchPasswords()
        } catch {
            print("Failed to save password: \(error.localizedDescription)")
        }
    }
 
    func updatePassword(id: NSManagedObjectID, accountType: String, username: String, password: String) {
        guard let encryptedUsername = EncryptionHelper.encrypt(username),
              let encryptedPassword = EncryptionHelper.encrypt(password) else {
            print("Failed to encrypt data")
            return
        }
        do {
            if let passwordToUpdate = try viewContext.existingObject(with: id) as? Password {
                passwordToUpdate.accountType = accountType
                passwordToUpdate.username = encryptedUsername
                passwordToUpdate.password = encryptedPassword
                try viewContext.save()
                fetchPasswords()
            }
        } catch {
            print("Failed to update password: \(error.localizedDescription)")
        }
    }
 
    func deletePassword(id: NSManagedObjectID) {
        do {
            if let passwordToDelete = try viewContext.existingObject(with: id) as? Password {
                viewContext.delete(passwordToDelete)
                try viewContext.save()
                fetchPasswords()
            }
        } catch {
            print("Failed to delete password: \(error.localizedDescription)")
        }
    }
}
