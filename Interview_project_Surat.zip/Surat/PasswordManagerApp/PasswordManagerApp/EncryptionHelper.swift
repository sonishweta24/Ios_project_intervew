//
//import Foundation
//import CryptoKit
//
//class EncryptionHelper {
//    static func encrypt(_ string: String) -> String {
//        // Your encryption logic here (e.g., AES, RSA)
//        // Placeholder encryption logic
//        let data = Data(string.utf8)
//        return data.base64EncodedString()
//    }
//    
//    static func decrypt(_ string: String) -> String {
//        // Your decryption logic here
//        // Placeholder decryption logic
//        guard let data = Data(base64Encoded: string),
//              let decryptedString = String(data: data, encoding: .utf8) else {
//            return ""
//        }
//        return decryptedString
//    }
//}
//
//
//
//import Foundation
//import CommonCrypto
//
//class EncryptionHelper {
//    private static let key = "your-encryption-key" // Use a strong key and keep it secure
//    private static let iv = "your-iv" // Use a strong IV and keep it secure
//
//    static func encrypt(_ string: String) -> String? {
//        if let data = string.data(using: .utf8) {
//            return dataEncrypt(data)?.base64EncodedString()
//        }
//        return nil
//    }
//
//    static func decrypt(_ string: String) -> String? {
//        if let data = Data(base64Encoded: string),
//           let decryptedData = dataDecrypt(data) {
//            return String(data: decryptedData, encoding: .utf8)
//        }
//        return nil
//    }
//
//    private static func dataEncrypt(_ data: Data) -> Data? {
//        return crypt(data, option: CCOperation(kCCEncrypt))
//    }
//
//    private static func dataDecrypt(_ data: Data) -> Data? {
//        return crypt(data, option: CCOperation(kCCDecrypt))
//    }
//
//    private static func crypt(_ data: Data, option: CCOperation) -> Data? {
//     //   var outLength = Int(0)
//        let outputData = UnsafeMutableRawPointer.allocate(byteCount: data.count + kCCBlockSizeAES128, alignment: 1)
//        defer { outputData.deallocate() }
//        
//        var numBytesEncrypted = 0
//        
//        let cryptStatus = CCCrypt(option,
//                                  CCAlgorithm(kCCAlgorithmAES128),            // algorithm
//                                  CCOptions(kCCOptionPKCS7Padding),           // options
//                                  key, key.count,                             // key and key length
//                                  iv,                                         // IV
//                                  (data as NSData).bytes, data.count,         // input data and length
//                                  outputData, data.count + kCCBlockSizeAES128,// output buffer and length
//                                  &numBytesEncrypted)                         // output bytes encrypted actual length
//
//        if UInt32(cryptStatus) == UInt32(kCCSuccess) {
//            return Data(bytes: outputData, count: numBytesEncrypted)
//        } else {
//            return nil
//        }
//    }
//}


import Foundation
import CommonCrypto
 
class EncryptionHelper {
    static let key: Data = generateRandomData(length: kCCKeySizeAES256) // 256-bit key
    static let iv: Data = generateRandomData(length: kCCBlockSizeAES128) // 128-bit IV
 
    static func encrypt(_ string: String) -> String? {
        guard let data = string.data(using: .utf8) else { return nil }
        return dataEncrypt(data: data)?.base64EncodedString()
    }
 
    static func decrypt(_ string: String) -> String? {
        guard let data = Data(base64Encoded: string) else { return nil }
        guard let decryptedData = dataDecrypt(data: data) else { return nil }
        return String(data: decryptedData, encoding: .utf8)
    }
 
    private static func dataEncrypt(data: Data) -> Data? {
        return crypt(data: data, option: CCOperation(kCCEncrypt))
    }
 
    private static func dataDecrypt(data: Data) -> Data? {
        return crypt(data: data, option: CCOperation(kCCDecrypt))
    }
 
    private static func crypt(data: Data, option: CCOperation) -> Data? {
        var numBytesEncrypted: size_t = 0
        var buffer = [UInt8](repeating: 0, count: data.count + kCCBlockSizeAES128)
        let status = data.withUnsafeBytes { dataBytes in
            key.withUnsafeBytes { keyBytes in
                iv.withUnsafeBytes { ivBytes in
                    CCCrypt(option,
                            CCAlgorithm(kCCAlgorithmAES128),
                            CCOptions(kCCOptionPKCS7Padding),
                            keyBytes.baseAddress,
                            key.count,
                            ivBytes.baseAddress,
                            dataBytes.baseAddress,
                            data.count,
&buffer,
                            buffer.count,
&numBytesEncrypted)
                }
            }
        }
 
        guard status == kCCSuccess else {
            print("Error: \(status)")
            return nil
        }
 
        return Data(bytes: buffer, count: numBytesEncrypted)
    }
 
    private static func generateRandomData(length: Int) -> Data {
        var data = Data(count: length)
        _ = data.withUnsafeMutableBytes { bytes in
            SecRandomCopyBytes(kSecRandomDefault, length, bytes.baseAddress!)
        }
        return data
    }
}
