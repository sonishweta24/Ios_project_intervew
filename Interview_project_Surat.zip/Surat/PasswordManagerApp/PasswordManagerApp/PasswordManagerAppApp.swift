//
//  PasswordManagerAppApp.swift
//  PasswordManagerApp
//
//  Created by Plugger Technologies on 24/07/24.
//

import SwiftUI

@main
struct PasswordManagerAppApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
