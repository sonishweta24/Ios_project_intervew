import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = PasswordViewModel()
    @State private var showingAddNewAccount = false
    
    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.passwords) { password in
                    NavigationLink(destination: AccountDetailView(viewModel: viewModel, password: password)) {
                        HStack {
                            Text(password.accountType)
                            Spacer()
                            Text("******")
                        }
                    }
                }
                .onDelete(perform: deleteItems)
            }
            .navigationTitle("Password Manager")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showingAddNewAccount = true
                    }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showingAddNewAccount) {
                AddNewAccountView(viewModel: viewModel)
            }
        }
    }
    
    private func deleteItems(offsets: IndexSet) {
        offsets.map { viewModel.passwords[$0].id }.forEach(viewModel.deletePassword)
    }
}

struct AddNewAccountView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var viewModel: PasswordViewModel
    @State private var accountType = ""
    @State private var username = ""
    @State private var password = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Account Details")) {
                    TextField("Account Type", text: $accountType)
                    TextField("Username/Email", text: $username)
                    SecureField("Password", text: $password)
                }
                
                Button(action: {
                    viewModel.addPassword(accountType: accountType, username: username, password: password)
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Text("Add New Account")
                        .frame(maxWidth: .infinity, alignment: .center)
                }
            }
            .navigationTitle("Add New Account")
            .navigationBarItems(trailing: Button("Cancel") {
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
}

struct AccountDetailView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var viewModel: PasswordViewModel
    @State var password: PasswordModel
    @State private var isEditing = false
    @State private var accountType = ""
    @State private var username = ""
    @State private var passwordText = ""
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        Form {
            Section(header: Text("Account Details")) {
                if isEditing {
                    TextField("Account Type", text: $accountType)
                        .textContentType(.none)
                    TextField("Username/Email", text: $username)
                        .textContentType(.username)
                        .autocapitalization(.none)
                        .keyboardType(.emailAddress)
                    SecureField("Password", text: $passwordText)
                        .textContentType(.password)
                } else {
                    Text("Account Type: \(password.accountType)")
                    Text("Username/Email: \(password.username)")
                    SecureField("Password", text: .constant("******")).disabled(true)
                }
            }
            
            HStack {
                if isEditing {
                    Button(action: {
                        if validateInputs() {
                            viewModel.updatePassword(id: password.id, accountType: accountType, username: username, password: passwordText)
                            isEditing = false
                            presentationMode.wrappedValue.dismiss()
                        }
                    }) {
                        Text("Save")
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                    .alert(isPresented: $showAlert) {
                        Alert(title: Text("Invalid Input"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                    }
                } else {
                    Button(action: {
                        isEditing.toggle()
                        accountType = password.accountType
                        username = password.username
                        passwordText = password.password
                    }) {
                        Text("Edit")
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                    
                    Button(action: {
                        viewModel.deletePassword(id: password.id)
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Text("Delete")
                            .foregroundColor(.red)
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                }
            }
        }
        .onAppear {
            accountType = password.accountType
            username = password.username
            passwordText = password.password
        }
        .navigationTitle("Account Details")
        .navigationBarItems(trailing: Button("Cancel") {
            presentationMode.wrappedValue.dismiss()
        })
    }
    
    private func validateInputs() -> Bool {
        if accountType.trimmingCharacters(in: .whitespaces).isEmpty {
            alertMessage = "Account Type cannot be empty."
            showAlert = true
            return false
        }
        if username.trimmingCharacters(in: .whitespaces).isEmpty || !isValidEmail(username) {
            alertMessage = "Please enter a valid email address."
            showAlert = true
            return false
        }
        if passwordText.trimmingCharacters(in: .whitespaces).isEmpty {
            alertMessage = "Password cannot be empty."
            showAlert = true
            return false
        }
        return true
    }
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
