

import Foundation
import CoreData


public class Password: NSManagedObject {

}
