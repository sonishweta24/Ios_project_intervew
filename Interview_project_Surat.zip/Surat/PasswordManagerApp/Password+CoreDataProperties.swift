//
//  Password+CoreDataProperties.swift
//  PasswordManagerApp
//
//  Created by Plugger Technologies on 24/07/24.
//
//

import Foundation
import CoreData


extension Password {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Password> {
        return NSFetchRequest<Password>(entityName: "Password")
    }

    @NSManaged public var accountType: String?
    @NSManaged public var username: String?
    @NSManaged public var password: String?

}

extension Password : Identifiable {

}
